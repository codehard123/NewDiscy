<?php

/* @author    2codeThemes
*  @package   WPQA/templates
*  @version   1.0
*/

echo do_shortcode("[wpqa_edit_profile]");?>