<?php

/* @author    2codeThemes
*  @package   WPQA/templates
*  @version   1.0
*/

include wpqa_get_template("head.php","profile/");
	
include wpqa_get_template("content.php","profile/");?>