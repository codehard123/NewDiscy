<?php get_header();
	$discy_sidebar_all = $discy_sidebar = discy_sidebars("sidebar_where");
	wpqa_content();
get_footer();?>