<?php get_header();
	include locate_template("theme-parts/content-none.php");
get_footer();?>